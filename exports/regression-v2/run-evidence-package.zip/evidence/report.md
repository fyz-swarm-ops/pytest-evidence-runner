# Verification Report

**Verdict:** failed

**Summary:** Pytest completed in Docker with 1 failed and 0 errored tests.

**Failure kind:** test_failure

## Run

- Run id: `run-7165a5526699`
- Execution mode: `docker`
- Started: `2026-10-08T17:43:18.438931+00:00`
- Finished: `2026-10-08T17:43:19.743752+00:00`
- Duration: `1.305` seconds
- Working directory: `/workspace/pytest-evidence-runner/samples/regression_v2`
- Command: `python -m pytest -q`
- Exit code: `1`

## Container

- Container id/name: `pytest-evidence-run-7165a5526699`
- Image: `pytest-evidence-runner:local`
- Image id: `sha256:b6d5c479c8801982463040fd0be20262d6838417becc3950dc56c4a782e56569`
- Docker: `Docker version 27.4.0, build bde2b89`
- Network disabled: `True`
- Privileged: `False`
- Resources: `cpus=1, memory=512m, pids_limit=256, tmpfs=/tmp:rw,nosuid,nodev,size=128m`
- Project mount: `/workspace/pytest-evidence-runner/samples/regression_v2:/workspace:ro`
- Evidence mount: `/workspace/pytest-evidence-runner/evidence/regression-v2:/evidence:rw`

## Test Session

- Status: `failed`
- Total: `4`
- Passed: `3`
- Failed: `1`
- Errors: `0`
- Skipped: `0`

### Test Cases

- `test-64dc442821f9f724` `passed` `tests.test_calculator.test_adds_numbers` (0.001s)
- `test-7fcf9195b9e086af` `failed` `tests.test_calculator.test_divides_numbers` (0.001s)
- `test-3c2ad2c09a2a32d1` `passed` `tests.test_calculator.test_normalizes_email` (0.0s)
- `test-0a9e36bce22309e3` `passed` `tests.test_calculator.test_multiplies_numbers` (0.0s)

## Failures

### `failure-0001` `failure` in `tests.test_calculator.test_divides_numbers`

Message: assert 2.6666666666666665 == 4
 +  where 2.6666666666666665 = divide(8, 2)

```text
def test_divides_numbers():
>       assert divide(8, 2) == 4
E       assert 2.6666666666666665 == 4
E        +  where 2.6666666666666665 = divide(8, 2)

tests/test_calculator.py:9: AssertionError
```

## Evidence Hashes

- `app/__init__.py` `01ba4719c80b6fe911b091a7c05124b64eeece964e09c058ef8f9805daca546b` (1 bytes)
- `app/calculator.py` `a66f2c7e62c1184ceea5584f65f64bcd2602270633f63ada62d5e7db785cbaba` (341 bytes)
- `tests/test_calculator.py` `cf50c2b6e09584858969d0d42f76975ab447ac9302227246898c0654865c6c93` (346 bytes)

## Artifacts

- `raw/docker-command.json` `5471ff0f50a8cc5ed56b22929a7fabfbfe5c15a2dfbd9222cf330f582624edd2` (824 bytes)
- `raw/docker-config/config.json` `81bcbd3f950f2b31b87a64e8eca0de39db52feb0060d2bc631d7d794696604eb` (13 bytes)
- `raw/docker-run.stderr.log` `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855` (0 bytes)
- `raw/docker-run.stdout.log` `f27fedba601dfca1f20015eccdf08792017006b7c5d5f2dd7ed8501ac6ee78b5` (1625 bytes)
- `raw/pytest-junit.xml` `6a2461532ed22f0cea7bec13707f1a1da58d40c7813420b595f7bac62da750b2` (912 bytes)

## Stdout

```text
.F..                                                                     [100%]
=================================== FAILURES ===================================
_____________________________ test_divides_numbers _____________________________

    def test_divides_numbers():
>       assert divide(8, 2) == 4
E       assert 2.6666666666666665 == 4
E        +  where 2.6666666666666665 = divide(8, 2)

tests/test_calculator.py:9: AssertionError
=============================== warnings summary ===============================
../usr/local/lib/python3.12/site-packages/_pytest/cacheprovider.py:475
  /usr/local/lib/python3.12/site-packages/_pytest/cacheprovider.py:475: PytestCacheWarning: could not create cache path /workspace/.pytest_cache/v/cache/nodeids: [Errno 30] Read-only file system: '/workspace/pytest-cache-files-6kggoy82'
    config.cache.set("cache/nodeids", sorted(self.cached_nodeids))

../usr/local/lib/python3.12/site-packages/_pytest/cacheprovider.py:429
  /usr/local/lib/python3.12/site-packages/_pytest/cacheprovider.py:429: PytestCacheWarning: could not create cache path /workspace/.pytest_cache/v/cache/lastfailed: [Errno 30] Read-only file system: '/workspace/pytest-cache-files-hcvkcudu'
    config.cache.set("cache/lastfailed", self.lastfailed)

-- Docs: https://docs.pytest.org/en/stable/how-to/capture-warnings.html
-------------- generated xml file: /evidence/raw/pytest-junit.xml --------------
=========================== short test summary info ============================
FAILED tests/test_calculator.py::test_divides_numbers - assert 2.666666666666...
1 failed, 3 passed, 2 warnings in 0.07s
```

## Stderr

```text

```

## Reproduce

- `python -m pytest_evidence_runner run --docker --project /workspace/pytest-evidence-runner/samples/regression_v2 --output-dir /workspace/pytest-evidence-runner/evidence/regression-v2`
- `docker run --name pytest-evidence-run-7165a5526699 --rm --network none --cpus 1 --memory 512m --pids-limit 256 --tmpfs /tmp:rw,nosuid,nodev,size=128m -v /workspace/pytest-evidence-runner/samples/regression_v2:/workspace:ro -v /workspace/pytest-evidence-runner/evidence/regression-v2:/evidence:rw -w /workspace --entrypoint python pytest-evidence-runner:local -m pytest -q --junitxml=/evidence/raw/pytest-junit.xml`
